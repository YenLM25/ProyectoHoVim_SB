// Espero a que la página cargue completamente antes de ejecutar
document.addEventListener("DOMContentLoaded", () => {
  // Hago la petición GET al backend para obtener todas las visitas
  fetch("http://localhost:8080/api/hoVim/visit")
    .then(res => res.json()) // Parseo la respuesta como JSON
    .then(visitas => {
      const tbody = document.querySelector("#visitsTable tbody");
      tbody.innerHTML = ""; // Limpio la tabla antes de agregar datos

      visitas.forEach(v => {
        const fila = `
          <tr>
            <td>${v.visitId}</td>
            <td>${v.patientId}</td>
            <td>${formatearFecha(v.date)}</td>
            <td>
              <span class="badge ${claseEstado(v.status)}">
                ${estadoLegible(v.status)}
              </span>
            </td>
            <td>
              <a href="edit-visit.html?id=${v.visitId}" class="btn btn-sm btn-warning me-2">
                <i class="fas fa-edit"></i> Editar
              </a>
              <button class="btn btn-sm btn-danger" onclick="eliminarVisita(${v.visitId})">
                <i class="fas fa-trash"></i> Eliminar
              </button>
            </td>
          </tr>
        `;
        tbody.insertAdjacentHTML("beforeend", fila);
      });
    })
    .catch(err => {
      console.error("Error al cargar visitas:", err);
      alert("❌ No se pudieron cargar las visitas médicas.");
    });
});

// Convierte fechas tipo "11/08/2024" a un formato legible
function formatearFecha(fechaStr) {
  const [dd, mm, yyyy] = fechaStr.split("/");
  const fecha = new Date(`${yyyy}-${mm}-${dd}`);
  return fecha.toLocaleDateString("es-CR", {
    year: "numeric",
    month: "short",
    day: "numeric"
  });
}

// Traduzco estado técnico a forma legible
function estadoLegible(estado) {
  switch (estado) {
    case "IN_PROGRESS": return "En Progreso";
    case "COMPLETED": return "Completado";
    default: return estado;
  }
}

function claseEstado(estado) {
  switch (estado) {
    case "IN_PROGRESS": return "badge-status status-in-progress";
    case "COMPLETED": return "badge-status status-completed";
    default: return "badge-status bg-light text-dark";
  }
}


// Envía petición DELETE al backend para eliminar una visita
function eliminarVisita(id) {
  if (confirm("¿Está seguro de eliminar esta visita?")) {
    fetch(`http://localhost:8080/api/hoVim/visit/${id}`, {
      method: "DELETE"
    })
      .then(() => location.reload())
      .catch(err => {
        console.error("Error al eliminar:", err);
        alert("❌ No se pudo eliminar la visita.");
      });
  }
}
