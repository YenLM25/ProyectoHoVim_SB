
  let listaAreas = [];

  document.addEventListener("DOMContentLoaded", () => {
    const modal = document.getElementById("horariosModal");

    modal.addEventListener("show.bs.modal", () => {
      // Limpiar selects y contenido anterior cada vez que se abre
      document.getElementById("selectAreaModal").innerHTML = '<option value="">-- Seleccionar --</option>';
      document.getElementById("infoAreaSeleccionada").innerHTML = "";

      // Cargar áreas
      fetch("http://localhost:8080/api/hoVim/area")
        .then(res => res.json())
        .then(areas => {
          listaAreas = areas;

          const selector = document.getElementById("selectAreaModal");
          areas.forEach(area => {
            const option = document.createElement("option");
            option.value = area.areaName;
            option.textContent = area.areaName;
            selector.appendChild(option);
          });

          selector.addEventListener("change", () => {
            const seleccionada = selector.value;
            const area = listaAreas.find(a => a.areaName === seleccionada);
            if (!area) {
              document.getElementById("infoAreaSeleccionada").innerHTML = "";
              return;
            }

            document.getElementById("infoAreaSeleccionada").innerHTML = `
              <h5><i class="fas fa-hospital me-2"></i>${area.areaName}</h5>
              <p><strong>Horario entre semana:</strong> ${area.weekdayVisitingHours}</p>
              <p><strong>Horario fin de semana:</strong> ${area.weekendVisitingHours}</p>
              <p><strong>Requisitos:</strong> ${area.visitingRequirements || "Ninguno"}</p>
            `;
          });
        })
        .catch(error => {
          console.error("Error al cargar las áreas:", error);
          document.getElementById("infoAreaSeleccionada").innerHTML = "<p class='text-danger'>No se pudo cargar la información.</p>";
        });
    });
  });

