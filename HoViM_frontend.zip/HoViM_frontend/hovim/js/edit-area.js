// Esperamos a que el DOM esté cargado completamente
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("areaForm");
  const areaId = obtenerIdDesdeURL();

  if (!areaId) {
    alert("ID de área no válido.");
    window.location.href = "area.html";
    return;
  }

  // 1. Cargo los datos del área desde el backend
  fetch(`http://localhost:8080/api/hoVim/area/${areaId}`)
    .then((res) => res.json())
    .then((area) => {
      document.getElementById("areaName").value = area.areaName;
      document.getElementById("totalRooms").value = area.totalRooms;
      document.getElementById("totalBeds").value = area.totalBeds;
      document.getElementById("weekdayVisitingHours").value = area.weekdayVisitingHours;
      document.getElementById("weekendVisitingHours").value = area.weekendVisitingHours;
      document.getElementById("visitingRequirements").value = area.visitingRequirements || "";
    })
    .catch((error) => {
      console.error("Error al cargar el área:", error);
      alert("No se pudo cargar la información del área.");
      window.location.href = "area.html";
    });

  // 2. Al enviar el formulario, capturo datos actualizados y los envío al backend
  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const datosActualizados = {
      areaId: parseInt(areaId),
      areaName: document.getElementById("areaName").value.trim(),
      totalRooms: parseInt(document.getElementById("totalRooms").value),
      totalBeds: parseInt(document.getElementById("totalBeds").value),
      weekdayVisitingHours: document.getElementById("weekdayVisitingHours").value.trim(),
      weekendVisitingHours: document.getElementById("weekendVisitingHours").value.trim(),
      visitingRequirements: document.getElementById("visitingRequirements").value.trim() || ""
    };

    // Validación básica
    if (
      !datosActualizados.areaName ||
      isNaN(datosActualizados.totalRooms) ||
      isNaN(datosActualizados.totalBeds) ||
      !datosActualizados.weekdayVisitingHours ||
      !datosActualizados.weekendVisitingHours
    ) {
      alert("Por favor, completá todos los campos obligatorios.");
      return;
    }

    // 3. Envío los cambios al backend
    fetch(`http://localhost:8080/api/hoVim/area/${areaId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(datosActualizados)
    })
      .then((res) => {
        if (!res.ok) {
          throw new Error("Error al actualizar el área");
        }
        window.location.href = "area.html"; // Redirijo al listado
      })
      .catch((error) => {
        console.error("Error al actualizar el área:", error);
        alert("Hubo un problema al guardar los cambios.");
      });
  });
});

// Función auxiliar que extrae el ID de área desde la URL actual
function obtenerIdDesdeURL() {
  const params = new URLSearchParams(window.location.search);
  return params.get("id");
}

