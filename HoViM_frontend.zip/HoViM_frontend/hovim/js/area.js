// Esperamos a que el DOM esté completamente listo
document.addEventListener("DOMContentLoaded", () => {
  cargarAreas(); // Inicializa la carga de datos al entrar en la vista
});

// Función principal: consulta el backend y construye la tabla
function cargarAreas() {
  fetch("http://localhost:8080/api/hoVim/area")
    .then((res) => res.json())
    .then((areas) => {
      const tbody = document.querySelector("#areaTable tbody");
      tbody.innerHTML = ""; // Limpio contenido previo por si recargo

      areas.forEach((area) => {
        const fila = document.createElement("tr");

        // Celdas con datos de la entidad área
        fila.innerHTML = `
        <td>${area.areaId}</td>
        <td>${area.areaName}</td>
        <td>${area.totalRooms}</td>
        <td>${area.totalBeds}</td>
        <td>${area.weekdayVisitingHours}</td>
        <td>${area.weekendVisitingHours}</td>
        <td>${area.visitingRequirements || "-"}</td>
        <td class="action-btns">
            <a href="edit-area.html?id=${area.areaId}" class="btn btn-sm btn-warning me-2">
            <i class="fas fa-edit"></i> Editar
            </a>
            <button class="btn btn-sm btn-danger" onclick="eliminarArea(${area.areaId})">
            <i class="fas fa-trash"></i> Eliminar
            </button>
        </td>

        `;

        // Agrego la fila al tbody
        tbody.appendChild(fila);
      });
    })
    .catch((error) => {
      console.error("Error al cargar las áreas:", error);
      alert("No se pudieron cargar las áreas registradas.");
    });
}

// Función que elimina un área médica por su ID
function eliminarArea(id) {
  if (confirm("¿Estás seguro de eliminar esta área?")) {
    fetch(`http://localhost:8080/api/hoVim/area/${id}`, {
      method: "DELETE",
    })
      .then((res) => {
        if (!res.ok) {
          throw new Error("Error al eliminar el área");
        }
        cargarAreas(); // Recargo la tabla para reflejar el cambio
      })
      .catch((error) => {
        console.error("Error al eliminar área:", error);
        alert("Ocurrió un error al intentar eliminar el área.");
      });
  }
}
