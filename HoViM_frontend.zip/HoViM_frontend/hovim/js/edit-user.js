// Espero a que el DOM esté completamente cargado antes de empezar
document.addEventListener("DOMContentLoaded", () => {
  // Extraigo el parámetro "id" desde la URL (ej: edit-user.html?id=3)
  const params = new URLSearchParams(window.location.search);
  const userId = params.get("id");

  // Referencia al formulario HTML
  const form = document.getElementById("editUserForm");

  // Si no hay ID en la URL, no puedo editar nada → redirijo al listado
  if (!userId) {
    alert("No se especificó el ID del usuario.");
    window.location.href = "user.html";
    return;
  }

  // Hago un GET al backend para traer los datos del usuario por ID
  fetch(`http://localhost:8080/api/hoVim/user/${userId}`)
    .then((res) => res.json())
    .then((data) => {
      // Lleno los campos del formulario con los datos existentes
      document.getElementById("userId").value = data.id;
      document.getElementById("userName").value = data.name;
      document.getElementById("userEmail").value = data.email;
      document.getElementById("userTelephone").value = data.telephone;
      document.getElementById("userType").value = data.userType;
    });

  // Al enviar el formulario, preparo el objeto editado y lo mando al backend
  form.addEventListener("submit", (e) => {
    e.preventDefault(); // Prevengo el comportamiento por defecto del form

    // Armo el objeto con los campos modificados
    const updatedUser = {
      name: document.getElementById("userName").value.trim(),
      email: document.getElementById("userEmail").value.trim(),
      telephone: document.getElementById("userTelephone").value.trim(),
      userType: document.getElementById("userType").value
    };

    // Hago un PUT al backend con el ID y los datos actualizados
    fetch(`http://localhost:8080/api/hoVim/user/${userId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedUser)
    })
    .then((res) => {
      // Si hubo un error en la respuesta, lanzo excepción
      if (!res.ok) throw new Error("Error al editar usuario");
      return res.json();
    })
    .then((data) => {
      // Si todo salió bien → aviso al usuario y redirijo
      alert(`✅ Usuario actualizado: ${data.name}`);
      window.location.href = "user.html"; // Vuelvo al listado de usuarios
    })
    .catch((err) => {
      // Si algo falla en el proceso (network, backend, etc), lo muestro
      alert("❌ No se pudo editar:\n" + err.message);
    });
  });
});
