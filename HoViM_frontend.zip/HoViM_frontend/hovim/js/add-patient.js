// Variables globales
let datosAreas = [];

// Ejecuta una vez que el DOM esté listo
document.addEventListener("DOMContentLoaded", () => {
  cargarAreas();

  const form = document.getElementById("patientForm");
  form.addEventListener("submit", guardarPaciente);
});

// Carga todas las áreas médicas en el <select>
function cargarAreas() {
  fetch("http://localhost:8080/api/hoVim/area")
    .then(res => res.json())
    .then(areas => {
      datosAreas = areas;
      const areaSelect = document.getElementById("areaSelect");

      areas.forEach(area => {
        const option = document.createElement("option");
        option.value = area.areaName;
        option.textContent = area.areaName;
        areaSelect.appendChild(option);
      });

      areaSelect.addEventListener("change", actualizarOpcionesSegunArea);
    })
    .catch(error => {
      console.error("Error al cargar áreas:", error);
      alert("No se pudieron cargar las áreas médicas.");
    });
}

// Cuando se selecciona un área, genero las habitaciones y camas válidas
function actualizarOpcionesSegunArea() {
  const areaSeleccionada = document.getElementById("areaSelect").value;
  const areaInfo = datosAreas.find(a => a.areaName === areaSeleccionada);

  if (!areaInfo) return;

  const roomSelect = document.getElementById("roomNumber");
  const bedSelect = document.getElementById("bedNumber");

  // Actualizo habitaciones
  roomSelect.innerHTML = '<option value="">Seleccione una habitación</option>';
  for (let i = 1; i <= areaInfo.totalRooms; i++) {
    const opt = document.createElement("option");
    opt.value = i;
    opt.textContent = `Habitación ${i}`;
    roomSelect.appendChild(opt);
  }

  // Actualizo camas
  bedSelect.innerHTML = '<option value="">Seleccione una cama</option>';
  for (let i = 1; i <= areaInfo.totalBeds; i++) {
    const opt = document.createElement("option");
    opt.value = i;
    opt.textContent = `Cama ${i}`;
    bedSelect.appendChild(opt);
  }
}

// Función principal para validar y guardar el paciente
function guardarPaciente(e) {
  e.preventDefault();

  const paciente = {
    patientName: document.getElementById("patientName").value.trim(),
    area: document.getElementById("areaSelect").value,
    floorNumber: parseInt(document.getElementById("floorNumber").value),
    rooms: parseInt(document.getElementById("roomNumber").value),
    bedNumber: parseInt(document.getElementById("bedNumber").value)
  };

  // Validación
  if (
    !paciente.patientName ||
    !paciente.area ||
    isNaN(paciente.floorNumber) ||
    isNaN(paciente.rooms) ||
    isNaN(paciente.bedNumber)
  ) {
    alert("Por favor, completá todos los campos obligatorios.");
    return;
  }

  // Envío al backend
  fetch("http://localhost:8080/api/hoVim/patient", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(paciente)
  })
    .then(res => {
      if (!res.ok) throw new Error("Error al registrar el paciente");
      window.location.href = "patient.html";
    })
    .catch(error => {
      console.error("Error al guardar paciente:", error);
      alert("No se pudo guardar el paciente.");
    });
}
