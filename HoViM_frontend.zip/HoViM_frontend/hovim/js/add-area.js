// Espero que el DOM esté completamente cargado para iniciar
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("areaForm");

  form.addEventListener("submit", (e) => {
    e.preventDefault(); // Evita recarga del formulario

    // Captura los valores del formulario
    const nuevaArea = {
      areaName: document.getElementById("areaName").value.trim(),
      totalRooms: parseInt(document.getElementById("totalRooms").value),
      totalBeds: parseInt(document.getElementById("totalBeds").value),
      weekdayVisitingHours: document.getElementById("weekdayVisitingHours").value.trim(),
      weekendVisitingHours: document.getElementById("weekendVisitingHours").value.trim(),
      visitingRequirements: document.getElementById("visitingRequirements").value.trim() || ""
    };

    // Validación rápida
    if (
      !nuevaArea.areaName ||
      isNaN(nuevaArea.totalRooms) ||
      isNaN(nuevaArea.totalBeds) ||
      !nuevaArea.weekdayVisitingHours ||
      !nuevaArea.weekendVisitingHours
    ) {
      alert("Por favor, completá todos los campos requeridos.");
      return;
    }

    // Envío de datos al backend
    fetch("http://localhost:8080/api/hoVim/area", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(nuevaArea)
    })
      .then((res) => {
        if (!res.ok) {
          throw new Error("Error al guardar el área");
        }
        // Redirección al módulo principal
        window.location.href = "area.html";
      })
      .catch((error) => {
        console.error("Error al guardar el área:", error);
        alert("No se pudo guardar el área. Verificá los datos e intentá nuevamente.");
      });
  });
});
