let datosAreas = [];
let pacienteOriginal = null;

document.addEventListener("DOMContentLoaded", () => {
  const id = obtenerIdPaciente();
  if (!id) {
    alert("ID de paciente no válido.");
    window.location.href = "patient.html";
    return;
  }

  cargarAreas(id); // Una vez cargadas las áreas, se cargan los datos del paciente

  const form = document.getElementById("patientForm");
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    actualizarPaciente(id);
  });
});

// Extrae el ID de la URL
function obtenerIdPaciente() {
  const params = new URLSearchParams(window.location.search);
  return params.get("id");
}

// Carga todas las áreas y luego el paciente
function cargarAreas(idPaciente) {
  fetch("http://localhost:8080/api/hoVim/area")
    .then((res) => res.json())
    .then((areas) => {
      datosAreas = areas;
      const areaSelect = document.getElementById("areaSelect");

      areas.forEach((area) => {
        const option = document.createElement("option");
        option.value = area.areaName;
        option.textContent = area.areaName;
        areaSelect.appendChild(option);
      });

      areaSelect.addEventListener("change", actualizarHabitacionesYCamas);

      cargarPaciente(idPaciente);
    })
    .catch((error) => {
      console.error("Error al cargar áreas:", error);
      alert("No se pudieron cargar las áreas.");
    });
}

// Trae los datos del paciente y los coloca en el formulario
function cargarPaciente(id) {
  fetch(`http://localhost:8080/api/hoVim/patient/${id}`)
    .then((res) => res.json())
    .then((paciente) => {
      pacienteOriginal = paciente;

      document.getElementById("patientName").value = paciente.patientName;
      document.getElementById("areaSelect").value = paciente.area;
      document.getElementById("floorNumber").value = paciente.floorNumber;

      // Genera habitaciones y camas correspondientes al área seleccionada
      actualizarHabitacionesYCamas(() => {
        document.getElementById("roomNumber").value = paciente.rooms;
        document.getElementById("bedNumber").value = paciente.bedNumber;
      });
    })
    .catch((error) => {
      console.error("Error al cargar el paciente:", error);
      alert("No se pudo cargar la información del paciente.");
      window.location.href = "patient.html";
    });
}

// Genera habitaciones y camas según el área seleccionada
function actualizarHabitacionesYCamas(callback) {
  const areaSeleccionada = document.getElementById("areaSelect").value;
  const area = datosAreas.find((a) => a.areaName === areaSeleccionada);

  if (!area) return;

  const roomSelect = document.getElementById("roomNumber");
  roomSelect.innerHTML = '<option value="">Seleccione una habitación</option>';
  for (let i = 1; i <= area.totalRooms; i++) {
    const opt = document.createElement("option");
    opt.value = i;
    opt.textContent = `Habitación ${i}`;
    roomSelect.appendChild(opt);
  }

  const bedSelect = document.getElementById("bedNumber");
  bedSelect.innerHTML = '<option value="">Seleccione una cama</option>';
  for (let i = 1; i <= area.totalBeds; i++) {
    const opt = document.createElement("option");
    opt.value = i;
    opt.textContent = `Cama ${i}`;
    bedSelect.appendChild(opt);
  }

  if (typeof callback === "function") {
    callback();
  }
}

// Envía los cambios actualizados al backend
function actualizarPaciente(id) {
  const pacienteActualizado = {
    patientId: parseInt(id),
    patientName: document.getElementById("patientName").value.trim(),
    area: document.getElementById("areaSelect").value,
    floorNumber: parseInt(document.getElementById("floorNumber").value),
    rooms: parseInt(document.getElementById("roomNumber").value),
    bedNumber: parseInt(document.getElementById("bedNumber").value)
  };

  // Validación
  if (
    !pacienteActualizado.patientName ||
    !pacienteActualizado.area ||
    isNaN(pacienteActualizado.floorNumber) ||
    isNaN(pacienteActualizado.rooms) ||
    isNaN(pacienteActualizado.bedNumber)
  ) {
    alert("Por favor, completá todos los campos.");
    return;
  }

  fetch(`http://localhost:8080/api/hoVim/patient/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(pacienteActualizado)
  })
    .then((res) => {
      if (!res.ok) throw new Error("Error al actualizar el paciente");
      window.location.href = "patient.html";
    })
    .catch((error) => {
      console.error("Error al actualizar paciente:", error);
      alert("No se pudieron guardar los cambios.");
    });
}
