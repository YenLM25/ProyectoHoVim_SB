// Almacena pacientes disponibles
let listaPacientes = [];

// Esperamos que el DOM cargue por completo
document.addEventListener("DOMContentLoaded", () => {
  cargarPacientes(); // Llena el <select> de pacientes

  const form = document.getElementById("visitForm");
  form.addEventListener("submit", guardarVisita);
});

// Carga el listado de pacientes registrados desde el backend
function cargarPacientes() {
  fetch("http://localhost:8080/api/hoVim/patient")
    .then(res => res.json())
    .then(pacientes => {
      listaPacientes = pacientes;
      const selector = document.getElementById("patientSelect");

      pacientes.forEach(p => {
        const opt = document.createElement("option");
        opt.value = p.patientId;
        opt.textContent = `${p.patientName} - Habitación ${p.rooms}, Cama ${p.bedNumber}`;
        selector.appendChild(opt);
      });
    })
    .catch(err => {
      console.error("Error al cargar pacientes:", err);
      alert("❌ No se pudieron cargar los pacientes.");
    });
}

// Maneja el envío del formulario
function guardarVisita(e) {
  e.preventDefault();

  const visita = {
    patientId: parseInt(document.getElementById("patientSelect").value),
    date: formatearFecha(document.getElementById("visitDate").value),
    status: document.getElementById("visitStatus").value
  };

  // Validación
  if (!visita.patientId || !visita.date || !visita.status) {
    alert("⚠️ Por favor, completá todos los campos requeridos.");
    return;
  }

  // Envío de datos al backend
  fetch("http://localhost:8080/api/hoVim/visit", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(visita)
  })
    .then(res => {
      if (!res.ok) throw new Error("Error al registrar la visita");
      return res.json();
    })
    .then(() => {
      alert("✅ Visita registrada correctamente.");
      window.location.href = "visit.html";
    })
    .catch(err => {
      console.error("Error al guardar visita:", err);
      alert("❌ No se pudo registrar la visita.");
    });
}

// Convierte fecha ISO (YYYY-MM-DD) → formato dd/MM/yyyy
function formatearFecha(fechaISO) {
  const [yyyy, mm, dd] = fechaISO.split("-");
  return `${dd}/${mm}/${yyyy}`;
}
