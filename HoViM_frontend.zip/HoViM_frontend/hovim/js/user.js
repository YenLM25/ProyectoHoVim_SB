// Espero a que el documento HTML esté completamente cargado antes de ejecutar el código
document.addEventListener("DOMContentLoaded", () => {
  // Hago una petición al backend para obtener todos los usuarios registrados
  fetch("http://localhost:8080/api/hoVim/user")
    .then(res => res.json()) // Parseo la respuesta a formato JSON
    .then(users => {
      // Obtengo el tbody de la tabla donde se mostrarán los usuarios
      const tbody = document.querySelector("#userTable tbody");
      tbody.innerHTML = ""; // Limpio cualquier contenido previo de la tabla

      // Recorro el array de usuarios y por cada uno creo una fila HTML
      users.forEach(user => {
        const row = `
          <tr>
            <td>${user.id}</td>                        <!-- ID del usuario -->
            <td>${user.name}</td>                      <!-- Nombre -->
            <td>${user.email}</td>                     <!-- Correo -->
            <td>${user.telephone}</td>                 <!-- Teléfono -->
            <td>${user.userType}</td>                  <!-- Tipo de usuario -->
            <td class="action-btns">
              <!-- Botón para editar el usuario → redirige con ID por query param -->
              <a href="edit-user.html?id=${user.id}" class="btn btn-sm btn-warning">
                <i class="fas fa-edit"></i> Editar
              </a>
              <!-- Botón para eliminar el usuario → ejecuta deleteUser(id) -->
              <button class="btn btn-sm btn-danger" onclick="deleteUser(${user.id})">
                <i class="fas fa-trash"></i> Eliminar
              </button>
            </td>
          </tr>`;
        // Inserto la fila construida en el tbody
        tbody.insertAdjacentHTML("beforeend", row);
      });
    })
    .catch(error => {
      // Si falla la petición (por backend caído o error de red), informo al usuario
      console.error("Error cargando usuarios:", error);
      alert("No se pudieron cargar los usuarios.");
    });
});

// Función que se ejecuta cuando se quiere eliminar un usuario
function deleteUser(id) {
  // Confirmación visual para evitar eliminación accidental
  if (confirm("¿Estás segura de eliminar este usuario?")) {
    // Hago la petición DELETE al backend con el ID correspondiente
    fetch(`http://localhost:8080/api/hoVim/user/${id}`, { method: "DELETE" })
      .then(() => location.reload()) // Recargo la página para que la tabla se actualice
      .catch(err => alert("Error al eliminar usuario.")); // Manejo de error si la petición falla
  }
}
