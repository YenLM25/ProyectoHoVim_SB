document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("visitForm");
  const params = new URLSearchParams(window.location.search);
  const visitId = params.get("id");

  if (!visitId) {
    alert("No se especificó la visita a editar.");
    window.location.href = "visit.html";
    return;
  }

  // Paso 1: obtengo los datos de la visita
  fetch(`http://localhost:8080/api/hoVim/visit/${visitId}`)
    .then(res => res.json())
    .then(data => {
      cargarPacientesYSeleccionar(data.patientId);
      document.getElementById("visitDate").value = convertirADateInput(data.date);
      document.getElementById("visitStatus").value = data.status;
    })
    .catch(err => {
      console.error("Error al cargar visita:", err);
      alert("No se pudo cargar la información de la visita.");
    });

  // Paso 2: envío del formulario
  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const visitaActualizada = {
      patientId: parseInt(document.getElementById("patientSelect").value),
      date: convertirAFormatoBackend(document.getElementById("visitDate").value),
      status: document.getElementById("visitStatus").value,
    };

    fetch(`http://localhost:8080/api/hoVim/visit/${visitId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(visitaActualizada)
    })
      .then(res => {
        if (!res.ok) throw new Error("Error al actualizar visita");
        return res.json();
      })
      .then(() => {
        alert("✅ Visita actualizada correctamente.");
        window.location.href = "visit.html";
      })
      .catch(err => {
        console.error("❌ Error al actualizar visita:", err);
        alert("No se pudo editar la visita.");
      });
  });
});

// 🔁 Cargar pacientes y seleccionar el correspondiente
function cargarPacientesYSeleccionar(patientIdActual) {
  fetch("http://localhost:8080/api/hoVim/patient")
    .then(res => res.json())
    .then(pacientes => {
      const selector = document.getElementById("patientSelect");

      pacientes.forEach(p => {
        const opt = document.createElement("option");
        opt.value = p.patientId;
        opt.textContent = `${p.patientName} - Habitación ${p.rooms}, Cama ${p.bedNumber}`;
        selector.appendChild(opt);
      });

      selector.value = patientIdActual;
    })
    .catch(err => {
      console.error("Error al cargar pacientes:", err);
      alert("No se pudieron cargar los pacientes.");
    });
}

// Formato para mostrar fecha en input
function convertirADateInput(fechaStr) {
  const [dd, mm, yyyy] = fechaStr.split("/");
  return `${yyyy}-${mm}-${dd}`;
}

// Formato para enviar fecha al backend
function convertirAFormatoBackend(iso) {
  const [yyyy, mm, dd] = iso.split("-");
  return `${dd}/${mm}/${yyyy}`;
}