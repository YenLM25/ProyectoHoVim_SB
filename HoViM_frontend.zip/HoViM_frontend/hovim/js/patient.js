// Espero que el DOM esté completamente cargado
document.addEventListener("DOMContentLoaded", () => {
  cargarPacientes(); // Inicializo la carga apenas entra al módulo
});

// Función que consulta el backend y renderiza la tabla
function cargarPacientes() {
  fetch("http://localhost:8080/api/hoVim/patient")
    .then((res) => res.json())
    .then((pacientes) => {
      const tbody = document.querySelector("#patientsTable tbody");
      tbody.innerHTML = ""; // Limpio contenido anterior

      pacientes.forEach((paciente) => {
        const fila = document.createElement("tr");

        fila.innerHTML = `
          <td>${paciente.patientId}</td>
          <td>${paciente.patientName}</td>
          <td>${paciente.area}</td>
          <td>${paciente.floorNumber}</td>
          <td>${paciente.rooms}</td>
          <td>${paciente.bedNumber}</td>
          <td class="action-btns">
            <a href="edit-patient.html?id=${paciente.patientId}" class="btn btn-sm btn-warning me-2">
              <i class="fas fa-edit"></i> Editar
            </a>
            <button class="btn btn-sm btn-danger" onclick="eliminarPaciente(${paciente.patientId})">
              <i class="fas fa-trash"></i> Eliminar
            </button>
          </td>
        `;

        tbody.appendChild(fila);
      });
    })
    .catch((error) => {
      console.error("Error al cargar los pacientes:", error);
      alert("Ocurrió un error al obtener la lista de pacientes.");
    });
}

// Función que permite eliminar un paciente por ID
function eliminarPaciente(id) {
  if (confirm("¿Estás seguro de eliminar este paciente?")) {
    fetch(`http://localhost:8080/api/hoVim/patient/${id}`, {
      method: "DELETE"
    })
      .then((res) => {
        if (!res.ok) {
          throw new Error("No se pudo eliminar el paciente");
        }
        cargarPacientes(); // Refresca la tabla tras eliminar
      })
      .catch((error) => {
        console.error("Error al eliminar paciente:", error);
        alert("No se pudo eliminar este paciente.");
      });
  }
}
