// Espero a que el documento esté completamente cargado antes de hacer nada
document.addEventListener("DOMContentLoaded", () => {
  // Busco el formulario por su ID (el que tiene los campos del usuario)
  const form = document.getElementById("userForm");

  // Escucho cuando se envía el formulario
  form.addEventListener("submit", (e) => {
    e.preventDefault(); // Evito que recargue la página (default del submit)

    // Capturo los valores que ingresó el usuario en el formulario
    const user = {
      name: document.getElementById("userName").value.trim(),         // Nombre completo
      email: document.getElementById("userEmail").value.trim(),       // Correo electrónico
      telephone: document.getElementById("userTelephone").value.trim(), // Teléfono (opcional)
      userType: document.getElementById("userType").value             // Tipo de usuario (select)
    };

    // Hago un POST al backend para guardar el usuario
    fetch("http://localhost:8080/api/hoVim/user", {
      method: "POST", // Método HTTP para crear
      headers: { "Content-Type": "application/json" }, // Mando JSON
      body: JSON.stringify(user) // Convierto el objeto a JSON
    })
    .then(async (res) => {
      // Si el backend responde con error, lo capturo y lo lanzo
      if (!res.ok) {
        const errorText = await res.text(); // Leo el mensaje de error del servidor
        throw new Error(errorText);
      }
      return res.json(); // Si todo OK, retorno el JSON con los datos del nuevo usuario
    })
    .then((data) => {
      // Si se guardó bien, guardo un mensaje de éxito en sessionStorage
      sessionStorage.setItem("message", `✅ Usuario agregado: ${data.name}`);

      // Redirecciono al listado de usuarios (user.html)
      window.location.href = "user.html";
    })
    .catch((err) => {
      // Si ocurre algún error en el proceso, lo muestro en consola y con alert
      console.error("❌ Error al guardar usuario:", err);
      alert("Error al guardar usuario:\n" + err.message);
    });
  });
});


